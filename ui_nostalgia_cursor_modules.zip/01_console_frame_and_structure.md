Target: add console bezel, screen area, and integrate existing containers.
Godot version: 4.3
... (content truncated for brevity in this message; full contents included in previous assistant message)
